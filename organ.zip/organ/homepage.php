<?php
/* Template name: Home */

get_header();
tmOrgan_theme_homepage();
get_footer();

?>