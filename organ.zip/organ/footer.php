<?php 

//theme footer

tmOrgan_theme_footer();

?>